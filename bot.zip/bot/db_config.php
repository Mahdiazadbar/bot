                                <?php
/**
 * DB configuration variables
 */
define("DB_SERVER", "localhost");
define("DB_USER", "mahdi");
define("DB_PASSWORD", "123456");
define("DB_DATABASE", 'schneide_rich');
?>
  