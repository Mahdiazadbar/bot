<?php


include 'database.php';
include 'lib/nusoap.php';

$myfunc = new func();


$query = $myfunc->database_helper();


if (!isset($_POST['State']) or $_POST['State'] != 'OK') {
    echo "پرداخت ناموفق";
    die;
}


$order_id = (int)$_POST['ResNum'];


$result = $query->query("SELECT * FROM tbl WHERE id='$order_id'");
$data = mysqli_fetch_array($result);

if (empty($data)) {
    echo "چنین تراکنشی موجود نیست";
    die;
}


 echo $data['amount'];
echo getRealIpAddr();
if ($data['ip'] != getRealIpAddr()) {
    echo "آی پی پرداخت کننده مطابقت ندارد";
    die;
}


//if ($data['state'] == '1') {
    //echo "تراکنش قبلا وریفای شده است !";
    //die;
//}


//if (!isset($_POST['RefNum'])) {
    //echo "رسید دیجیتال ست نشده است";
    //die;
//}
$ref_num = $_POST['RefNum'];
//$check =$data['ref_num'];
//if (!empty($check)) {
 //   echo "رسید دیجیتال قبلا ثبت شده است ";
  //  die;
//}


try {
    $soapclient = new nusoap_client('https://verify.sep.ir/payments/referencepayment.asmx?WSDL', 'wsdl');
    $soapProxy = $soapclient->getProxy();

    $mid = 11269651; // شماره مشتری بانک سامان
    $pass = 6763878; // پسورد بانک سامان
    $result = $soapProxy->VerifyTransaction($ref_num, $mid);

} catch (Exception $e) {
    echo "خطا در اتصال به وبسرویس ";
    die;
}

if ($result != ($data['amount'])) {
    // مغایرت مبلغ پرداختی

    if ($result < 0) {
        echo "کد خطای بانک سامان $result ";
        die;
    }

    // مغایرت و برگشت دادن وجه به حساب مشتری
    if ($result > 0) {
        echo "شما باید مبلغ {$data['amount']} ریال را پرداخت میکردید در صورتیکه مبلغ {$result}ریال را پرداخت کردید ! مبلغ شما به حسابتان برگشت داده شد آخرین بارتان باشد !!!";
        $soapProxy->ReverseTransaction($ref_num, $mid, $pass, $result);
    }
}

if ($result == ($data['amount'])) {
    // تراکنش موفق و ثبت شماره رسید دیجیتال

    $text="UPDATE tbl SET ref_num='$ref_num',state=1 WHERE id='$order_id'";

    $aff = $query->query($text);
    if (!$aff)
        die('خطا در ثبت اطلاعات');




    ?>

    <p style="text-align: center;">&nbsp;</p>
    <p style="text-align: center;">&nbsp;</p>
    <p style="text-align: center;">&nbsp;</p>
    <p style="text-align: center;">&nbsp;</p>
    <p style="text-align: center;">&nbsp;</p>
    <p style="text-align: center;">&nbsp;</p>
    <p style="text-align: center;">&nbsp;</p>
    <p style="text-align: center;">پرداخت شما با موفقیت انجام شد</p>
    <p style="text-align: center;">شماره پیگیری&nbsp;</p>
    <p style="text-align: center;"><?php  echo $ref_num; ?></p>
    <p style="text-align: center;">&nbsp;</p>
    <p style="text-align: center;">شماره فاکتور&nbsp;</p>
    <p style="text-align: center;"><?php  echo $order_id; ?></p>
    <p style="text-align: center;">به برنامه برگشته و در لیست پولدارها نام خود را ببینید&nbsp;</p>


<?php


}




function getRealIpAddr()
{
    if (!empty($_SERVER['HTTP_CLIENT_IP']))   //check ip from share internet
    {
        $ip=$_SERVER['HTTP_CLIENT_IP'];
    }
    elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR']))   //to check ip is pass from proxy
    {
        $ip=$_SERVER['HTTP_X_FORWARDED_FOR'];
    }
    else
    {
        $ip=$_SERVER['REMOTE_ADDR'];
    }
    return '192.168.1.1';
}
?>