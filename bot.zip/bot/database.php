<?php

class func {

function database_helper(){
	$servername = "localhost";
$username = "mahdi";
$password = "123456";
$dbname = "schneide_rich";

$ourconnection = new mysqli($servername, $username, $password, $dbname);
$ourconnection->set_charset('utf8');
return $ourconnection;
}

}



?>